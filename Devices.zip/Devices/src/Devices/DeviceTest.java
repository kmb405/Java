package Devices;

public class DeviceTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Phone myPhone1 = new Phone();
		
		myPhone1.makeCall();
		myPhone1.makeCall();
		myPhone1.makeCall();
		myPhone1.playGame();
		myPhone1.playGame();
		myPhone1.playGame();
		myPhone1.playGame();
//		myPhone1.charge();
	}

}
